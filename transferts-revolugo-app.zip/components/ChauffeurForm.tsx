import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function ChauffeurForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    pickup: "",
    dropoff: "",
    date: "",
    time: "",
    type: "aller-simple",
    vehicle: "berline",
  });

  const [price, setPrice] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (field: string, value: string) => {
    setForm({ ...form, [field]: value });
  };

  const calculatePrice = () => {
    const { type, vehicle } = form;
    let total = 0;
    if (type === "aller-simple" && vehicle === "berline") total = 150;
    if (type === "aller-simple" && vehicle === "van") total = 190;
    if (type === "aller-retour" && vehicle === "berline") total = 290;
    if (type === "aller-retour" && vehicle === "van") total = 370;
    setPrice(total);
  };

  const handleSubmit = () => {
    calculatePrice();
    setSubmitted(true);
  };

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4 text-[#1A2B49]">Réserver un transfert avec chauffeur</h1>
      {!submitted ? (
        <Card>
          <CardContent className="space-y-4 pt-6">
            <div>
              <Label>Nom</Label>
              <Input value={form.name} onChange={e => handleChange("name", e.target.value)} />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={form.email} onChange={e => handleChange("email", e.target.value)} />
            </div>
            <div>
              <Label>Téléphone</Label>
              <Input value={form.phone} onChange={e => handleChange("phone", e.target.value)} />
            </div>
            <div>
              <Label>Adresse de prise en charge</Label>
              <Input value={form.pickup} onChange={e => handleChange("pickup", e.target.value)} />
            </div>
            <div>
              <Label>Adresse de destination</Label>
              <Input value={form.dropoff} onChange={e => handleChange("dropoff", e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Date</Label>
                <Input type="date" value={form.date} onChange={e => handleChange("date", e.target.value)} />
              </div>
              <div>
                <Label>Heure</Label>
                <Input type="time" value={form.time} onChange={e => handleChange("time", e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Type de trajet</Label>
              <RadioGroup
                value={form.type}
                onValueChange={val => handleChange("type", val)}
                className="space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="aller-simple" id="aller-simple" />
                  <Label htmlFor="aller-simple">Aller simple</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="aller-retour" id="aller-retour" />
                  <Label htmlFor="aller-retour">Aller-retour</Label>
                </div>
              </RadioGroup>
            </div>
            <div>
              <Label>Type de véhicule</Label>
              <RadioGroup
                value={form.vehicle}
                onValueChange={val => handleChange("vehicle", val)}
                className="space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="berline" id="berline" />
                  <Label htmlFor="berline">Berline (1-3 pers)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="van" id="van" />
                  <Label htmlFor="van">Van (4-7 pers)</Label>
                </div>
              </RadioGroup>
            </div>
            <Button className="w-full mt-4 bg-[#1A2B49] hover:bg-[#142038]" onClick={handleSubmit}>
              Voir le tarif
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="text-center bg-white shadow-xl rounded-xl p-6">
          <h2 className="text-xl font-semibold text-[#1A2B49] mb-2">Prix estimé : {price} €</h2>
          <p className="mb-4">Cliquez ci-dessous pour procéder au paiement sécurisé.</p>
          <a
            href="https://buy.stripe.com/test_placeholder"
            target="_blank"
            className="inline-block bg-[#1A2B49] text-white px-6 py-2 rounded-xl"
          >
            Payer avec Stripe
          </a>
        </div>
      )}
    </div>
  );
}